import { categories } from "../data/questions";

interface MainMenuProps {
  onCategorySelect: (categoryId: string) => void;
  onHowToPlay: () => void;
}

const menuItems = [
  {
    id: "play",
    label: "Играй",
    sub: "Започни новата игра",
    icon: "▶",
    primary: true,
  },
  {
    id: "how",
    label: "Как се играе",
    sub: "Правила и инструкции",
    icon: "?",
    primary: false,
  },
];

const stats = [
  { label: "Въпроси", value: "15", icon: "📜" },
  { label: "Епохи", value: "4", icon: "🏛️" },
  { label: "Трудност", value: "Средна", icon: "⚔️" },
  { label: "Времетраене", value: "~7 мин", icon: "⏳" },
];

export function MainMenu({
  onCategorySelect,
  onHowToPlay,
}: MainMenuProps) {
  return (
    <div className="min-h-screen bg-[#111111] text-white flex flex-col relative overflow-hidden">
      {/* Hero background */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1627673989543-af63ca11a0a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmNpZW50JTIwcm9tYW4lMjBjb2xvc3NldW0lMjBkcmFtYXRpYyUyMGRhcmt8ZW58MXx8fHwxNzcyNjEwMTgwfDA&ixlib=rb-4.1.0&q=80&w=1080"
          alt=""
          className="w-full h-full object-cover opacity-20"
        />
        {/* Multi-layer gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#111111] via-[#111111]/70 to-[#111111]/30" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#111111]/80 via-transparent to-[#111111]/80" />
      </div>

      {/* Decorative top border */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />

      {/* Navbar */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-5 md:px-12">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-md bg-white/10 border border-white/20 flex items-center justify-center text-xs">
            🏛
          </div>
          <span className="text-xs uppercase tracking-[0.3em] text-neutral-400">
            Historia Quiz
          </span>
        </div>
        <div className="flex items-center gap-1 bg-white/5 border border-white/10 rounded-full px-3 py-1">
          <span className="text-xs text-neutral-500">v</span>
          <span className="text-xs text-neutral-400">1.0</span>
        </div>
      </nav>

      {/* Hero Content */}
      <div className="relative z-10 flex flex-col items-center justify-center flex-1 px-6 pt-8 pb-12 text-center gap-10 max-w-4xl mx-auto w-full">
        {/* Badge */}
        <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs uppercase tracking-[0.25em] text-neutral-400">
            История на света
          </span>
        </div>

        {/* Title */}
        <div className="flex flex-col items-center gap-4">
          <h1 className="text-6xl md:text-7xl text-white tracking-tight leading-none">
            Quiz
          </h1>
          <h2 className="text-6xl md:text-7xl text-neutral-600 tracking-tight leading-none -mt-2">
            по История
          </h2>
          <p className="text-neutral-500 max-w-sm mt-3 text-sm leading-relaxed">
            Изберете епоха и изпитайте знанията си за
            най-важните моменти в историята
          </p>
        </div>

        {/* Divider */}
        <div className="w-full flex items-center gap-4 max-w-2xl">
          <div className="flex-1 h-px bg-white/8" />
          <span className="text-xs text-neutral-600 uppercase tracking-widest">
            изберете епоха
          </span>
          <div className="flex-1 h-px bg-white/8" />
        </div>

        {/* Category cards - bigger and as main CTAs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-2xl">
          {categories.map((category) => {
            const isDisabled = category.questions.length === 0;
            return (
              <button
                key={category.id}
                onClick={() =>
                  !isDisabled && onCategorySelect(category.id)
                }
                disabled={isDisabled}
                className={`bg-gradient-to-br ${category.color} border ${category.border} rounded-2xl p-6 text-left flex flex-col gap-3 transition-all duration-200 ${
                  isDisabled
                    ? "opacity-40 cursor-not-allowed"
                    : "hover:scale-[1.02] hover:shadow-2xl active:scale-[0.98] cursor-pointer"
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex flex-col gap-1">
                    <span
                      className={`text-lg ${category.textColor}`}
                    >
                      {category.title}
                    </span>
                    <span className="text-neutral-500 text-sm">
                      {category.description}
                    </span>
                  </div>
                  {isDisabled ? (
                    <span className="text-neutral-600 text-xs bg-white/5 px-2 py-1 rounded-full">
                      Скоро
                    </span>
                  ) : (
                    <span className="text-white text-sm opacity-50">
                      →
                    </span>
                  )}
                </div>
                {!isDisabled && (
                  <div className="text-xs text-neutral-600">
                    {category.questions.length} въпроса
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Secondary button */}
        <button
          onClick={onHowToPlay}
          className="bg-white/5 border border-white/10 text-neutral-300 py-3 px-6 rounded-full hover:bg-white/10 hover:border-white/20 active:scale-95 transition-all duration-200 text-sm"
        >
          Как се играе
        </button>

        {/* Stats row */}
        <div className="grid grid-cols-4 gap-3 w-full max-w-md mt-4">
          {stats.map((s) => (
            <div
              key={s.label}
              className="flex flex-col items-center gap-1.5 bg-white/4 border border-white/8 rounded-xl py-3 px-2"
            >
              <span className="text-base">{s.icon}</span>
              <span className="text-white text-xs">
                {s.value}
              </span>
              <span className="text-neutral-600 text-xs leading-tight text-center">
                {s.label}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom decoration */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
    </div>
  );
}