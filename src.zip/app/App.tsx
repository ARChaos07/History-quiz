import { useState } from "react";
import { MainMenu } from "./components/MainMenu";
import { HowToPlay } from "./components/HowToPlay";
import { Question, categories, getRandomQuestions } from "./data/questions";

const optionLabels = ["А", "Б", "В", "Г"];

type QuizState = "menu" | "howtoplay" | "playing" | "result";

export default function App() {
  const [quizState, setQuizState] = useState<QuizState>("menu");
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [showFact, setShowFact] = useState(false);

  const handleCategorySelect = (categoryId: string) => {
    const categoryQuestions = getRandomQuestions(categoryId); // Без параметър count - вземи всички въпроси
    if (categoryQuestions.length === 0) {
      return; // Не трябва да се случи заради disabled state, но за сигурност
    }
    
    setQuestions(categoryQuestions);
    setSelectedCategory(categoryId);
    setQuizState("playing");
    setCurrentQuestion(0);
    setSelectedOption(null);
    setScore(0);
    setAnswers(Array(categoryQuestions.length).fill(null));
    setShowFact(false);
  };

  const handleStart = () => {
    setQuizState("playing");
    setCurrentQuestion(0);
    setSelectedOption(null);
    setScore(0);
    setAnswers(Array(questions.length).fill(null));
    setShowFact(false);
  };

  const handleOptionSelect = (index: number) => {
    if (selectedOption !== null) return;
    setSelectedOption(index);
    setShowFact(true);
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = index;
    setAnswers(newAnswers);
    if (index === questions[currentQuestion].correct) {
      setScore((prev) => prev + 1);
    }
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1);
      setSelectedOption(null);
      setShowFact(false);
    } else {
      setQuizState("result");
    }
  };

  const getScoreMessage = () => {
    if (score === questions.length) return "Перфектен резултат! Истински историк! 🏆";
    if (score >= questions.length * 0.8) return "Отличен резултат! Браво! 🎉";
    if (score >= questions.length * 0.6) return "Добър резултат! Продължавай да учиш! 📚";
    if (score >= questions.length * 0.4) return "Средно ниво. Има какво да се подобри! 📖";
    return "Нужно е повече четене по история! 💪";
  };

  const getScoreColor = () => {
    if (score >= questions.length * 0.8) return "text-emerald-400";
    if (score >= questions.length * 0.6) return "text-yellow-400";
    if (score >= questions.length * 0.4) return "text-orange-400";
    return "text-red-400";
  };

  const q = questions[currentQuestion];
  const progress = ((currentQuestion + (selectedOption !== null ? 1 : 0)) / questions.length) * 100;
  const category = categories.find(c => c.id === selectedCategory);

  if (quizState === "menu") {
    return (
      <MainMenu
        onCategorySelect={handleCategorySelect}
        onHowToPlay={() => setQuizState("howtoplay")}
      />
    );
  }

  if (quizState === "howtoplay") {
    return (
      <HowToPlay
        onBack={() => setQuizState("menu")}
        onPlay={() => {}} // Вече не се използва директно play от howtoplay
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#1a1a1a] text-white flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background image overlay */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <img
          src="https://images.unsplash.com/photo-1694265423616-4061edf49bed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmNpZW50JTIwaGlzdG9yeSUyMHJ1aW5zJTIwcHJ5YW1pZHMlMjBkYXJrfGVufDF8fHx8MTc3MjYwOTcxM3ww&ixlib=rb-4.1.0&q=80&w=1080"
          alt=""
          className="w-full h-full object-cover"
        />
      </div>

      {/* Decorative gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#1a1a1a] via-[#1a1a1a]/95 to-[#0d1117] pointer-events-none" />

      <div className="relative z-10 w-full max-w-2xl">
        {/* START SCREEN */}
        {quizState === "playing" && q && (
          <div className="flex flex-col gap-6">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setQuizState("menu")}
                  className="text-neutral-500 hover:text-white transition-colors text-sm"
                >
                  ← Назад
                </button>
                <span className="text-xs uppercase tracking-[0.25em] text-neutral-500">
                  {category?.title}
                </span>
              </div>
              <span className="text-sm text-neutral-400">
                <span className="text-white">{currentQuestion + 1}</span>
                <span> / {questions.length}</span>
              </span>
            </div>

            {/* Progress bar */}
            <div className="w-full h-0.5 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full bg-white rounded-full transition-all duration-500"
                style={{ width: `${((currentQuestion) / questions.length) * 100}%` }}
              />
            </div>

            {/* Score chip */}
            <div className="flex justify-end">
              <div className="flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-full px-3 py-1">
                <span className="text-xs text-neutral-400">Точки:</span>
                <span className="text-white text-xs">{score}</span>
              </div>
            </div>

            {/* Question */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <p className="text-white leading-relaxed">{q.question}</p>
            </div>

            {/* Options */}
            <div className="flex flex-col gap-3">
              {q.options.map((option, index) => {
                const isSelected = selectedOption === index;
                const isCorrect = index === q.correct;
                const isRevealed = selectedOption !== null;

                let stateClasses =
                  "bg-white/5 border-white/10 text-neutral-300 hover:bg-white/10 hover:border-white/20 cursor-pointer";

                if (isRevealed) {
                  if (isCorrect) {
                    stateClasses =
                      "bg-emerald-500/15 border-emerald-500/50 text-emerald-300 cursor-default";
                  } else if (isSelected) {
                    stateClasses =
                      "bg-red-500/15 border-red-500/50 text-red-300 cursor-default";
                  } else {
                    stateClasses =
                      "bg-white/3 border-white/5 text-neutral-600 cursor-default";
                  }
                }

                return (
                  <button
                    key={index}
                    onClick={() => handleOptionSelect(index)}
                    className={`flex items-center gap-4 border rounded-xl px-5 py-3.5 text-left transition-all duration-200 ${stateClasses}`}
                  >
                    <span
                      className={`shrink-0 w-7 h-7 rounded-full border flex items-center justify-center text-xs transition-all duration-200 ${
                        isRevealed && isCorrect
                          ? "border-emerald-400 text-emerald-400 bg-emerald-400/10"
                          : isRevealed && isSelected && !isCorrect
                          ? "border-red-400 text-red-400 bg-red-400/10"
                          : isRevealed
                          ? "border-white/10 text-neutral-600"
                          : "border-white/20 text-neutral-400"
                      }`}
                    >
                      {optionLabels[index]}
                    </span>
                    <span className="text-sm">{option}</span>
                    {isRevealed && isCorrect && (
                      <span className="ml-auto text-emerald-400 text-lg">✓</span>
                    )}
                    {isRevealed && isSelected && !isCorrect && (
                      <span className="ml-auto text-red-400 text-lg">✗</span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Fact box */}
            {showFact && (
              <div className="bg-white/5 border border-white/10 rounded-xl p-4 animate-fade-in">
                <p className="text-xs uppercase tracking-widest text-neutral-500 mb-2">
                  Интересен факт
                </p>
                <p className="text-neutral-300 text-sm leading-relaxed">
                  {q.fact}
                </p>
              </div>
            )}

            {/* Next button */}
            {selectedOption !== null && (
              <button
                onClick={handleNext}
                className="self-end bg-white text-[#1a1a1a] px-8 py-3 rounded-full hover:bg-neutral-200 transition-all duration-200 active:scale-95 text-sm"
              >
                {currentQuestion < questions.length - 1
                  ? "Следващ въпрос →"
                  : "Виж резултата →"}
              </button>
            )}
          </div>
        )}

        {/* RESULT SCREEN */}
        {quizState === "result" && (
          <div className="flex flex-col items-center gap-8 text-center">
            <div className="flex flex-col items-center gap-2">
              <span className="text-xs uppercase tracking-[0.3em] text-neutral-400 border border-neutral-700 px-4 py-1.5 rounded-full">
                {category?.title}
              </span>
              <span className="text-xs uppercase tracking-[0.3em] text-neutral-500">
                Резултат
              </span>
            </div>

            <div className="flex flex-col items-center gap-2">
              <div
                className={`text-7xl font-light ${getScoreColor()}`}
              >
                {score}
                <span className="text-3xl text-neutral-600">/{questions.length}</span>
              </div>
              <p className="text-neutral-300 mt-2">{getScoreMessage()}</p>
            </div>

            {/* Score breakdown */}
            <div className="w-full grid grid-cols-2 gap-3">
              <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-4 flex flex-col items-center gap-1">
                <span className="text-emerald-400 text-2xl">{score}</span>
                <span className="text-xs text-neutral-500 uppercase tracking-wider">Верни</span>
              </div>
              <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex flex-col items-center gap-1">
                <span className="text-red-400 text-2xl">{questions.length - score}</span>
                <span className="text-xs text-neutral-500 uppercase tracking-wider">Грешни</span>
              </div>
            </div>

            {/* Answers review */}
            <div className="w-full flex flex-col gap-2 text-left">
              <p className="text-xs uppercase tracking-widest text-neutral-500 mb-1">
                Преглед на отговорите
              </p>
              {questions.map((q, i) => {
                const userAnswer = answers[i];
                const isCorrect = userAnswer === q.correct;
                return (
                  <div
                    key={q.id}
                    className={`flex items-start gap-3 border rounded-xl px-4 py-3 ${
                      isCorrect
                        ? "bg-emerald-500/8 border-emerald-500/20"
                        : "bg-red-500/8 border-red-500/20"
                    }`}
                  >
                    <span
                      className={`shrink-0 mt-0.5 text-base ${
                        isCorrect ? "text-emerald-400" : "text-red-400"
                      }`}
                    >
                      {isCorrect ? "✓" : "✗"}
                    </span>
                    <div className="flex flex-col gap-0.5">
                      <p className="text-neutral-300 text-xs leading-snug">
                        {q.question}
                      </p>
                      {!isCorrect && (
                        <p className="text-emerald-400 text-xs">
                          Верен: {q.options[q.correct]}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            <button
              onClick={() => setQuizState("menu")}
              className="bg-white text-[#1a1a1a] px-10 py-3.5 rounded-full hover:bg-neutral-200 transition-all duration-200 active:scale-95 mt-2"
            >
              Главно меню
            </button>
          </div>
        )}
      </div>
    </div>
  );
}