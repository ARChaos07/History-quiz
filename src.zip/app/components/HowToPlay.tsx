interface HowToPlayProps {
  onBack: () => void;
}

const steps = [
  {
    num: "01",
    title: "Прочетете въпроса",
    desc: "Всеки въпрос е свързан с важно историческо събитие или личност. Прочетете внимателно преди да отговорите.",
    icon: "📜",
  },
  {
    num: "02",
    title: "Изберете отговор",
    desc: "Имате 4 варианта (А, Б, В, Г). Щракнете върху избрания отговор — той не може да се промени.",
    icon: "👆",
  },
  {
    num: "03",
    title: "Научете факта",
    desc: "След всеки отговор ще видите интересен исторически факт свързан с въпроса.",
    icon: "💡",
  },
  {
    num: "04",
    title: "Вижте резултата",
    desc: "След 15 въпроса получавате финален резултат с преглед на всички верни и грешни отговори.",
    icon: "🏆",
  },
];

const scoring = [
  { range: "15/15", label: "Перфектен историк", color: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/20" },
  { range: "12–14/15", label: "Отличен резултат", color: "text-yellow-400", bg: "bg-yellow-500/10 border-yellow-500/20" },
  { range: "9–11/15", label: "Добро ниво", color: "text-orange-400", bg: "bg-orange-500/10 border-orange-500/20" },
  { range: "0–8/15", label: "Учи повече!", color: "text-red-400", bg: "bg-red-500/10 border-red-500/20" },
];

export function HowToPlay({ onBack }: HowToPlayProps) {
  return (
    <div className="min-h-screen bg-[#111111] text-white flex flex-col relative overflow-hidden">
      {/* Subtle background texture */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#111111] via-[#161616] to-[#0d0d0d] pointer-events-none" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/15 to-transparent" />

      {/* Navbar */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-5 md:px-12">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-neutral-400 hover:text-white transition-colors text-sm"
        >
          <span>←</span>
          <span>Назад</span>
        </button>
        <span className="text-xs uppercase tracking-[0.3em] text-neutral-600">
          Как се играе
        </span>
        <div className="w-16" />
      </nav>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center px-6 pb-16 pt-4 max-w-2xl mx-auto w-full gap-10">

        {/* Title */}
        <div className="flex flex-col items-center text-center gap-3">
          <h2 className="text-4xl text-white">Правила на играта</h2>
          <p className="text-neutral-500 text-sm max-w-sm">
            Изберете епоха от главното меню и проверете познанията си с 15 въпроса
          </p>
        </div>

        {/* Steps */}
        <div className="w-full flex flex-col gap-3">
          <p className="text-xs uppercase tracking-widest text-neutral-600 mb-1">Стъпки</p>
          {steps.map((step, i) => (
            <div
              key={step.num}
              className="flex items-start gap-4 bg-white/4 border border-white/8 rounded-2xl p-5"
            >
              <div className="shrink-0 w-10 h-10 rounded-xl bg-white/6 border border-white/10 flex items-center justify-center text-xl">
                {step.icon}
              </div>
              <div className="flex flex-col gap-1 flex-1">
                <div className="flex items-center justify-between">
                  <span className="text-white text-sm">{step.title}</span>
                  <span className="text-xs text-neutral-700">{step.num}</span>
                </div>
                <p className="text-neutral-500 text-xs leading-relaxed">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Scoring */}
        <div className="w-full flex flex-col gap-3">
          <p className="text-xs uppercase tracking-widest text-neutral-600 mb-1">Оценяване</p>
          <div className="grid grid-cols-2 gap-3">
            {scoring.map((s) => (
              <div
                key={s.range}
                className={`border rounded-xl p-4 flex flex-col gap-1.5 ${s.bg}`}
              >
                <span className={`text-lg ${s.color}`}>{s.range}</span>
                <span className="text-neutral-400 text-xs">{s.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Note */}
        <div className="w-full bg-white/4 border border-white/8 rounded-xl p-4 flex items-start gap-3">
          <span className="text-yellow-400 mt-0.5">⚠</span>
          <p className="text-neutral-400 text-xs leading-relaxed">
            След като веднъж изберете отговор, той не може да бъде променен. Помислете добре преди да отговорите!
          </p>
        </div>

        {/* CTA */}
        <button
          onClick={onBack}
          className="w-full max-w-xs bg-white text-[#111111] py-3.5 px-8 rounded-full hover:bg-neutral-100 active:scale-95 transition-all duration-200 text-sm"
        >
          ← Обратно към менюто
        </button>
      </div>
    </div>
  );
}